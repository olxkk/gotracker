from __future__ import annotations

import time
import discord
from discord import app_commands
from discord.ext import commands

from .helpers import guild_id, no_guild_message


class GeneralCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Show the bot's slash commands")
    async def help_command(self, interaction: discord.Interaction):
        embed = discord.Embed(title="Anime & Manga Tracker — help", description="Use slash commands. Many title fields offer autocomplete. Searches do not automatically add results to a watchlist.", color=discord.Color.blurple())
        embed.add_field(name="Tracking", value="`/track add` · `/track remove` · `/track list` · `/track search` · `/track info`", inline=False)
        embed.add_field(name="Releases", value="`/release next` · `/release latest` · `/release check` · `/release upcoming` · `/release history`", inline=False)
        embed.add_field(name="News", value="`/news title` · `/news upcoming`", inline=False)
        embed.add_field(name="Notifications", value="`/notify settings` · `/notify channel` · `/notify target` · `/notify role` · `/notify user` · `/notify everyone` · `/notify title` · `/notify types` · `/notify quiet-hours` · `/notify preview`", inline=False)
        embed.add_field(name="General", value="`/status` · `/settings` · `/help`", inline=False)
        embed.set_footer(text="Anime schedules are not proof of streaming availability; manga chapter dates are shown only when reliable data exists.")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="status", description="Show uptime, watchlist size, source health, and last successful checks")
    async def status(self, interaction: discord.Interaction):
        tracks = (await self.bot.repo.list_tracks(int(interaction.guild_id))
                  if interaction.guild_id else await self.bot.repo.all_tracked_titles())
        health = await self.bot.repo.source_health()
        started = int(getattr(self.bot, "started_at", time.time()))
        uptime = max(0, int(time.time()) - started)
        days, rem = divmod(uptime, 86400)
        hours, rem = divmod(rem, 3600)
        minutes, _ = divmod(rem, 60)
        embed = discord.Embed(title="Bot status", color=discord.Color.green())
        embed.add_field(name="Uptime", value=f"{days}d {hours}h {minutes}m", inline=True)
        embed.add_field(name="Tracked title entries", value=str(len(tracks)), inline=True)
        embed.add_field(name="Polling interval", value=f"{self.bot.settings.poll_interval_seconds // 60} minutes", inline=True)
        if health:
            lines = []
            for row in health[:10]:
                stamp = f"<t:{int(row['last_success_at'])}:R>" if row.get("last_success_at") else "never"
                state = "healthy" if not row.get("consecutive_failures") else f"{row['consecutive_failures']} consecutive failure(s)"
                lines.append(f"**{row['source']}**: {state}; last success {stamp}")
            embed.add_field(name="Data source health", value="\n".join(lines)[:1024], inline=False)
        else:
            embed.add_field(name="Data source health", value="No checks have completed yet.", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="settings", description="Show effective bot and this server's settings")
    async def settings(self, interaction: discord.Interaction):
        embed = discord.Embed(title="Tracker settings", color=discord.Color.blurple())
        embed.add_field(name="Provider availability", value=f"AniList: enabled\nKitsu: enabled\nMyAnimeList: {'enabled' if self.bot.settings.mal_client_id else 'disabled (optional client ID not configured)'}\nRSS feeds: {len(self.bot.rss_provider.feeds)} configured", inline=False)
        embed.add_field(name="Monitoring", value=f"Poll interval: {self.bot.settings.poll_interval_seconds} seconds\nHTTP timeout: {self.bot.settings.request_timeout_seconds} seconds\nDatabase: persistent SQLite file", inline=False)
        if interaction.guild_id:
            row = await self.bot.repo.ensure_guild(int(interaction.guild_id))
            channel = f"<#{row['notification_channel_id']}>" if row.get("notification_channel_id") else "not configured"
            embed.add_field(name="This server", value=f"Notification channel: {channel}\nTarget: {row.get('default_target','none')}\n@everyone: {'enabled' if row.get('everyone_enabled') else 'disabled'}", inline=False)
        embed.set_footer(text="Commands that change server settings require Manage Server; enabling @everyone requires Administrator and exact confirmation.")
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(GeneralCog(bot))
