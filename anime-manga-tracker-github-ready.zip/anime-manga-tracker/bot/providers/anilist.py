from __future__ import annotations

import asyncio
import time
from typing import Any

import aiohttp

from .base import MediaTitle

GRAPHQL_URL = "https://graphql.anilist.co"
MEDIA_FIELDS = """
 id type format status episodes chapters siteUrl description(asHtml:false)
 title { romaji english native }
 coverImage { large }
 startDate { year month day } endDate { year month day }
 nextAiringEpisode { airingAt timeUntilAiring episode }
"""


class AniListProvider:
    name = "AniList"

    def __init__(self, session: aiohttp.ClientSession | None = None, timeout: int = 15, max_bytes: int = 2_000_000):
        self.session = session
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.max_bytes = max_bytes
        self._lock = asyncio.Lock()
        self._last_request = 0.0

    async def _graphql(self, query: str, variables: dict[str, Any]) -> dict[str, Any]:
        if self.session is None:
            raise RuntimeError("AniList provider has no HTTP session")
        async with self._lock:
            # Gentle pacing protects against bursts as well as the published rate limit.
            delay = 2.5 - (time.monotonic() - self._last_request)
            if delay > 0:
                await asyncio.sleep(delay)
            self._last_request = time.monotonic()
        for attempt in range(3):
            try:
                async with self.session.post(
                    GRAPHQL_URL,
                    json={"query": query, "variables": variables},
                    timeout=self.timeout,
                    headers={"Accept": "application/json", "Content-Type": "application/json"},
                ) as response:
                    raw = await response.content.read(self.max_bytes + 1)
                    if len(raw) > self.max_bytes:
                        raise ValueError("AniList response exceeded configured size limit")
                    if response.status == 429 and attempt < 2:
                        try:
                            retry_text = response.headers.get("Retry-After", "5")
                            wait = min(60, max(1, int(retry_text)))
                        except ValueError:
                            wait = 5
                        await asyncio.sleep(wait)
                        continue
                    if response.status >= 500 and attempt < 2:
                        await asyncio.sleep(2 ** attempt)
                        continue
                    if response.status >= 400:
                        raise RuntimeError(f"AniList returned HTTP {response.status}")
                    try:
                        payload = await _json_loads(raw)
                    except Exception as exc:
                        raise ValueError("AniList returned invalid JSON") from exc
                    if payload.get("errors"):
                        message = str(payload["errors"][0].get("message", "GraphQL error"))[:200]
                        raise RuntimeError(f"AniList API error: {message}")
                    return payload.get("data") or {}
            except (aiohttp.ClientError, asyncio.TimeoutError):
                if attempt >= 2:
                    raise
                await asyncio.sleep(2 ** attempt)
        raise RuntimeError("AniList request failed after retries")

    async def search(self, query: str, media_format: str = "ANIME", limit: int = 8) -> list[MediaTitle]:
        if not query.strip():
            return []
        graphql = f"query ($search: String, $type: MediaType, $perPage: Int) {{ Page(perPage: $perPage) {{ media(search: $search, type: $type, sort: SEARCH_MATCH) {{{MEDIA_FIELDS}}} }} }}"
        data = await self._graphql(graphql, {"search": query.strip()[:100], "type": _media_type(media_format), "perPage": min(max(limit, 1), 10)})
        return [_from_anilist(row) for row in data.get("Page", {}).get("media", []) if isinstance(row, dict)]

    async def get(self, external_id: str, media_format: str = "ANIME") -> MediaTitle | None:
        try:
            media_id = int(external_id)
        except (TypeError, ValueError):
            return None
        graphql = f"query ($id: Int, $type: MediaType) {{ Media(id: $id, type: $type) {{{MEDIA_FIELDS}}} }}"
        data = await self._graphql(graphql, {"id": media_id, "type": _media_type(media_format)})
        item = data.get("Media")
        return _from_anilist(item) if isinstance(item, dict) else None


def _media_type(media_format: str) -> str:
    return "MANGA" if str(media_format).upper() == "MANGA" else "ANIME"


def _date_parts(value: Any) -> str:
    if not isinstance(value, dict) or not value.get("year"):
        return ""
    return f"{int(value['year']):04d}-{int(value.get('month') or 1):02d}-{int(value.get('day') or 1):02d}"


def _from_anilist(row: dict[str, Any]) -> MediaTitle:
    titles = row.get("title") or {}
    title = titles.get("english") or titles.get("romaji") or titles.get("native") or f"AniList #{row.get('id')}"
    next_airing = row.get("nextAiringEpisode") or {}
    status = str(row.get("status") or "UNKNOWN").upper()
    return MediaTitle(
        provider="anilist", external_id=str(row.get("id")), title=str(title)[:250],
        format=_media_type(row.get("type", "ANIME")), url=str(row.get("siteUrl") or f"https://anilist.co/{str(row.get('type','ANIME')).lower()}/{row.get('id')}"),
        cover_url=str((row.get("coverImage") or {}).get("large") or "")[:1000],
        description=str(row.get("description") or "")[:1500], status=status,
        episodes=_optional_int(row.get("episodes")), chapters=_optional_int(row.get("chapters")),
        next_airing_at=_optional_int(next_airing.get("airingAt")), next_episode=_optional_int(next_airing.get("episode")),
        start_date=_date_parts(row.get("startDate")), end_date=_date_parts(row.get("endDate")), source_url=str(row.get("siteUrl") or ""),
    )


def _optional_int(value: Any) -> int | None:
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


async def _json_loads(raw: bytes) -> dict[str, Any]:
    import json
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Expected JSON object")
    return value
